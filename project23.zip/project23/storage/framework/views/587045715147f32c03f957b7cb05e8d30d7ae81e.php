<!DOCTYPE html>
<html>
<head>
	<title>Trang chủ giảng viên</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/style.css?v=<?php echo time()?>">
</head>
<body>
	<ul id="menu">
		<li> <a id="giang_vien_cham_cong" > Chấm công </a></li>
		<li> <a id="xem_luong"> Xem lương </a></li>	</ul>
	<p id="content">
		
	</p>
	<script type="text/javascript">
		$("#giang_vien_cham_cong").click(function () {
			$.ajax({
			async:false,
			type: "get",
			url: "http://localhost/project23/public/giao_vu/cham_cong/view_cham_cong",
			success: function (response) {
				$("#content").html(response);
			}
		});
		})

		$("#xem_luong").click(function () {
			$.ajax({
			async:false,
			type: "get",
			url: "",
			success: function (response) {
				$("#content").html(response);
			}
		});
		})
	</script>
</body>
</html>