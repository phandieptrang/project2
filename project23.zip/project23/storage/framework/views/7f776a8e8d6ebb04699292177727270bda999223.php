<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Xem lương</title>
</head>
<body>
    <table>
        <tr>
            <td>
                Tháng 
            </td>
            <td>
                Năm
            </td>
            <td>
                Mã giảng viên
            </td>
            <td>
                Số giờ làm
            </td>
            <td>
                Lương
            </td>
        </tr>
        <?php $__currentLoopData = $array_luong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $luong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
        <tr>
            <td>
                <?php echo e($luong->thang); ?>

            </td>
            <td>
                <?php echo e($luong->nam); ?>

            </td>
            <td>
                <?php echo e($luong->ma_giang_vien); ?>

            </td>
            <td>
                <?php echo e($luong->so_gio_lam); ?>

            </td>
            <td>
                <?php echo e($luong->luong); ?>

            </td>
        </tr>
    }
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        

    
    </table>
</body>
</html>