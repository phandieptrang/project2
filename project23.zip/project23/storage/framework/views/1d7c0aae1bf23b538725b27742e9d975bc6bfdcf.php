<!DOCTYPE html>
<html>
<head>
	<title>Update Môn</title>
	<link rel="stylesheet" type="text/css" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>
<body>
	
	<div class="container">
		<h1>Update Môn Học</h1>
		<div class="col-lg-4">
			<form action="<?php echo e(route('mon.process_update')); ?>" method="post" accept-charset="utf-8">
			<?php echo e(csrf_field()); ?>

				<div class="form-group">
				<label>Chọn chuyên ngành</label>
				<input type="hidden" name="ma_mon" value="<?php echo e($mon->ma_mon); ?>">
				<select class="form-control" name="ma_chuyen_nganh" id="ma_chuyen_nganh">
					<?php $__currentLoopData = $array_chuyen_nganh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chuyen_nganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<option value="<?php echo e($chuyen_nganh->ma_chuyen_nganh); ?>" <?php if($chuyen_nganh->ma_chuyen_nganh == $mon->ma_chuyen_nganh ): ?>selected <?php endif; ?> >
							<?php echo e($chuyen_nganh->ten_chuyen_nganh); ?>

						</option>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				</div>
				<div class="form-group">
				<label>Tên môn học</label>
				<input type="text" name="ten_mon" value="<?php echo e($mon->ten_mon); ?>">
				</div>
				<div class="form-group">
					<label>Thời gian định mức</label>
					<input name="thoi_gian_dinh_muc" type="text" value="<?php echo e($mon->thoi_gian_dinh_muc); ?>">
					</div>
				<div class="form-group">
					<label>Lương từng môn</label>
					<input name="luong_tung_mon" type="text" value="<?php echo e($mon->luong_tung_mon); ?>">
				</div>
				<div class="form-group">
					<button type="submit">Update</button>
				
					<button>
							<a href="<?php echo e(url()->previous()); ?>">Quay lại</a>
					</button>
				</div>
			</form>
	</div>
	</div>
	
</body>
</html>