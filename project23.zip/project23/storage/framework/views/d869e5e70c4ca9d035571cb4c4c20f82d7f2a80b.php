<!DOCTYPE html>
<html>
<head>
	<title>Chuyên ngành</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap.css')); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.css')); ?>"/>
	<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
</head>
<body >
	<p>
	<h1>Danh sách chuyên ngành</h1>
	<table border="1" width="100%">
		<caption>
			<button>
				<a href="<?php echo e(route('chuyen_nganh.view_insert')); ?>">
					Thêm Chuyên Ngành
				</a>
			</button>
		</caption>
		<tr>
			<th>STT</th>
			<th>Tên chuyên ngành</th>
		</tr>
		<?php $__currentLoopData = $array_chuyen_nganh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chuyen_nganh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($chuyen_nganh->ma_chuyen_nganh); ?></td>
				<td><?php echo e($chuyen_nganh->ten_chuyen_nganh); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</p>
</body>
</html>