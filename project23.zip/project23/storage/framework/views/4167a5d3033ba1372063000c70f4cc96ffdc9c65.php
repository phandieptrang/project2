<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.css')); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bảng phân công lịch dạy</title>
</head>
<body>
    <div class="container">
        <h1>Phân công giảng viên </h1>
            <table width="100%" border="1">
                <tr>
                    <td>Môn</td>
                    <td>Lớp</td>
                    <td>Tổng số giờ dạy</td>
                </tr>
                <?php $__currentLoopData = $array_phan_cong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phan_cong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($phan_cong -> ten_mon); ?> </td>
                    <td> <?php echo e($phan_cong -> ten_lop); ?> </td>
                    <td> <?php echo e($phan_cong -> thoi_gian_dinh_muc_mon); ?> </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
</body>
</html>