<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap.css')); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.css')); ?>"/>
	<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
</head>
<body>
	<h1 align="center">Danh sách phân công</h1>
<table width="100%" border="1">
	<caption>
		<a href="<?php echo e(route('phan_cong.view_insert')); ?>">
			<button >Thêm Phân Công</button>
		</a>
	</caption>
	<tr>
		<th>Giảng viên</th>
		<th>Lớp</th>
		<th>Môn</th>
		<th>Thời gian định mức môn</th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $array_phan_cong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phan_cong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($phan_cong->ten_giang_vien); ?></td>
			<td><?php echo e($phan_cong->ten_lop); ?></td>
			<td><?php echo e($phan_cong->ten_mon); ?></td>
			<td><?php echo e($phan_cong->thoi_gian_dinh_muc_mon); ?></td>
			<td>
				<button>
					<a href="<?php echo e(route('phan_cong.view_update',['ma'=>$phan_cong->ma_giang_vien])); ?>">Update</a>
				</button>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>