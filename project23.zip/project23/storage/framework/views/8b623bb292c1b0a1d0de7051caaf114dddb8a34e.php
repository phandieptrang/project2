<!DOCTYPE html>
<html>
<head>
	<title>List He So</title>
	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap.css')); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.css')); ?>"/>
	<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
</head>
<body >
	<div class="container">
		<h1 align="center">Danh Sách Hệ Số Giảng Viên</h1>
		Tìm Kiếm : 
				<form id="frmSearch">
					<input type="text" name="key" id="search">
					<button type="submit" onclick="submitsearch()">Search</button>
				</form><br><br>
		<div class="form-group">
			<table border="1" width=100%>
				<tr>
					<th>Tên Giảng Viên</th>
					<th>Hệ Số</th>
				</tr>
				<?php $__currentLoopData = $array_giang_vien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giang_vien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($giang_vien->ten_giang_vien); ?></td>
					<td><?php echo e($giang_vien->he_so); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
	<script>
		function submitsearch()
		{
			
		}
	</script>
</body>
</html>