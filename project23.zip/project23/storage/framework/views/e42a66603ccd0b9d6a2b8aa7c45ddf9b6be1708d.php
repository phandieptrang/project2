<!DOCTYPE html>
<html>
<head>
	<title>Môn học</title>
</head>
<body>
	<h1>Danh sách các môn học</h1>
	<table border="1" width="100%">
		<caption>
			<button>
				<a href="<?php echo e(route('mon.view_insert')); ?>">
					Thêm Môn
				</a>
			</button>
		</caption>
		<tr>
			<th>STT</th>
			<th>Tên môn học</th>
			<th>Chuyên ngành</th>
			<th>Lương từng môn</th>
			<th>Thời gian định mức</th>
			<th></th>
		</tr>
		<?php $__currentLoopData = $array_mon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($mon->ma_mon); ?></td>
				<td><?php echo e($mon->ten_mon); ?></td>
				<td><?php echo e($mon->ten_chuyen_nganh); ?></td>
				<td><?php echo e($mon->luong_tung_mon); ?></td>
				<td><?php echo e($mon->thoi_gian_dinh_muc); ?></td>
				<td>
					<a href="<?php echo e(route('mon.view_update',['ma' => $mon->ma_mon])); ?>">Update</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>
	
</body>
</html>