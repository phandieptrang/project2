<!DOCTYPE html>
<html>
<head>
	<title>update phân công</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/boostrap.css')); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/select2.css')); ?>"/>
	<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
</head>
<body>
		<div class="container">
			<h1>Update Phân Công </h1>
			<div class="col-lg-4">
			<form action="<?php echo e(route('phan_cong.process_update')); ?>" method="post" accept-charset="utf-8">
				<?php echo e(csrf_field()); ?>

				<div class="form-group" id="div_mon">
					<label>Môn Học  : </label>
					<?php $__currentLoopData = $array_mon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($mon->ma_mon == $phan_cong->ma_mon): ?>
							<?php echo e($mon->ten_mon); ?><input type="hidden" name="ma_mon" value="<?php echo e($mon->ma_mon); ?>">
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				<div class="form-group">
					<label>Lớp Học  : </label>
					<?php $__currentLoopData = $array_lop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($lop->ma_lop == $phan_cong->ma_lop): ?>
							<?php echo e($lop->ten_lop); ?><input type="hidden" name="ma_lop" value="<?php echo e($lop->ma_lop); ?>">
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
					<div class="form-group">
					<label>Chọn Giảng Viên</label>
					<select class="form-control" name="ma_giang_vien">
						<?php $__currentLoopData = $array_giang_vien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giang_vien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($giang_vien->ma_giang_vien); ?>"<?php if($giang_vien->ma_giang_vien==$phan_cong->ma_giang_vien): ?>selected <?php endif; ?>>
								<?php echo e($giang_vien->ten_giang_vien); ?>

							</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					</div>
					<div class="form-group">
						<label>Thời gian định mức</label>
						<input type="number" name="thoi_gian_dinh_muc_mon" value="<?php echo e($phan_cong->thoi_gian_dinh_muc_mon); ?>">
					</div>
					<div class="form-group" id="div_button">
						<button type="submit">Update</button>
					
						<button>
								<a href="<?php echo e(url()->previous()); ?>">Quay lại</a>
						</button>
					</div>
			</form>
		</div>
	</div>
</body>
</html>

	